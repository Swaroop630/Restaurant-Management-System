export interface Table {
    id: number;
    position: number;
    capacity : number;
};